const BrowserRouter = ReactRouterDOM.BrowserRouter
      
ReactDOM.render(
  <BrowserRouter>
      <App />
  </BrowserRouter>
  
  
  , document.getElementById('root'))